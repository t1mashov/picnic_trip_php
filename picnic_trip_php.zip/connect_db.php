<?php

// $connect = mysqli_connect("localhost", "root", "11111111", "picnic_trip1");
$connect = mysqli_connect("std-mysql.ist.mospolytech.ru", "std_2022_picnic_trip", "11111111", "std_2022_picnic_trip");
mysqli_set_charset($connect, "utf8");
?>